import { ComputedRef, Ref } from 'vue'
export type LayoutKey = "default"
declare module "/home/jlabrada/Documents/sources/experiments/vue/nuxt3/nuxt3-tailwinds-storybook/node_modules/nuxt/dist/pages/runtime/composables" {
  interface PageMeta {
    layout?: false | LayoutKey | Ref<LayoutKey> | ComputedRef<LayoutKey>
  }
}