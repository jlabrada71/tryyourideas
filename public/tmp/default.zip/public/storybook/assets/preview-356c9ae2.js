const o={actions:{argTypesRegex:"^on[A-Z].*"},controls:{matchers:{color:/(background|color)$/i,date:/Date$/}}};export{o as parameters};
//# sourceMappingURL=preview-356c9ae2.js.map
