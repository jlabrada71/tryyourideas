<template>
  <div>
    <p>Content inside <code>default</code> layout</p>
    <br>
    <NuxtLink to="/">
      Back to home
    </NuxtLink>
  </div>
</template>