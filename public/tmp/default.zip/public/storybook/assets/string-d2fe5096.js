var e=Object.defineProperty;var n=(t,r)=>e(t,"name",{value:r,configurable:!0});var s=n(function(r){if(!r)return"";if(typeof r=="string")return r;throw new Error("Description: expected string, got: ".concat(JSON.stringify(r)))},"str");export{s};
//# sourceMappingURL=string-d2fe5096.js.map
