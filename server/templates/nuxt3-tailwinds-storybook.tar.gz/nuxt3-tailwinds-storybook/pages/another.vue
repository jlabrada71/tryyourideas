<template>
  <h1 class="text-lg text-gray-500">Hellow Nuxt</h1>
  <div>
    <HelloWorld />
  </div>
</template>
