<template>
    <nav class="flex align-center gap-4 p-4">
    <NuxtLink to="/default">
        Default layout
    </NuxtLink>
    <h1 class="text-lg text-gray-500">Hellow Nuxt</h1>
    </nav>
    <Products />
    <Button label="This is a test button"></Button>
</template>