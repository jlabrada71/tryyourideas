var r=Object.defineProperty;var o=(n,t)=>r(n,"name",{value:t,configurable:!0});import{at as e,au as a}from"./es.object.get-own-property-descriptor-e29e6b77.js";var c=e,i=a;c("Map",function(n){return o(function(){return n(this,arguments.length?arguments[0]:void 0)},"Map")},i);
//# sourceMappingURL=es.map.constructor-e79c747a.js.map
