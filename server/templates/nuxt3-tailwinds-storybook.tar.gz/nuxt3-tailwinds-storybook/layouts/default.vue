<template>
  <div>
    <slot />
  </div>
</template>
