
import { defuFn } from '/home/jlabrada/Documents/sources/experiments/vue/nuxt3/nuxt3-tailwinds-storybook/node_modules/defu/dist/defu.mjs'

const inlineConfig = {}



export default defuFn(inlineConfig)
